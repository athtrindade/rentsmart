# RentSmart — Sistema de Orçamento de Locação (R.M Imóveis)

Aplicação em Python orientada a objetos desenvolvida para automatizar o cálculo de orçamentos de locação da **R.M Imóveis**, aplicar regras comerciais por categoria de imóvel, separar a cobrança do aluguel mensal e da taxa contratual, e exportar a projeção de **12 meses** em formato `.csv`.

## Estrutura do Projeto

```text
rentsmart/
├── models.py     # Hierarquia POO (Imovel, Apartamento, Casa, Estudio)
├── orcamento.py  # Cálculo do orçamento, resumo detalhado e exportação CSV de 12 meses
├── main.py       # Interface interativa de linha de comando e validação de entradas
└── README.md     # Instruções de execução e regras implementadas
```

## Pré-requisitos

- **Python 3.10+** instalado no sistema.
- Não há dependências externas (`abc`, `csv`, `datetime`, `dataclasses` e `pathlib` fazem parte da biblioteca padrão do Python).

## Como Executar

1. Extraia o conteúdo do arquivo `.zip` mantendo a pasta `rentsmart/`.
2. Abra o terminal (Prompt de Comando, PowerShell ou bash) dentro da pasta `rentsmart/`:

```bash
cd rentsmart
python main.py
```
*(Em alguns sistemas Linux/macOS, utilize `python3 main.py`).*

3. Responda às perguntas solicitadas no terminal. Ao final do cálculo, o sistema exibirá o resumo completo na tela e criará automaticamente um arquivo `projecao_12_meses_AAAAMMDD_HHMMSS.csv` na mesma pasta.

## Regras de Negócio Implementadas

- **Apartamento:** Aluguel base de R$ 700,00 (1 quarto); adicional de R$ 200,00 para 2 quartos; acréscimo de R$ 300,00 para vaga de garagem; desconto de **5%** sobre o subtotal do aluguel (após adicionais) quando o cliente não possui crianças.
- **Casa:** Aluguel base de R$ 900,00 (1 quarto); adicional de R$ 250,00 para 2 quartos; acréscimo de R$ 300,00 para vaga de garagem.
- **Estúdio:** Aluguel base de R$ 1.200,00; pacote inicial de 2 vagas por R$ 250,00 + R$ 60,00 por vaga adicional.
- **Taxa Contratual:** Valor total de R$ 2.000,00, parcelável de **1x a 5x**, exibido separadamente do aluguel mensal e refletido na projeção de 12 meses em CSV.
