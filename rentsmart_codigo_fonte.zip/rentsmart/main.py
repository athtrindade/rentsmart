from models import Apartamento, Casa, Estudio, Imovel
from orcamento import OrcamentoLocacao


def ler_opcao(mensagem: str, opcoes_validas: tuple[str, ...]) -> str:
    while True:
        valor = input(mensagem).strip().lower()
        if valor in opcoes_validas:
            return valor
        print(f"Entrada inválida. Escolha uma das opções: {', '.join(opcoes_validas)}.")


def ler_inteiro_intervalo(mensagem: str, minimo: int, maximo: int | None = None) -> int:
    while True:
        bruto = input(mensagem).strip()
        try:
            numero = int(bruto)
            if numero < minimo:
                print(f"Digite um número inteiro maior ou igual a {minimo}.")
                continue
            if maximo is not None and numero > maximo:
                print(f"Digite um número inteiro entre {minimo} e {maximo}.")
                continue
            return numero
        except ValueError:
            print("Entrada inválida. Digite apenas números inteiros.")


def construir_imovel() -> Imovel:
    print("\n--- Seleção do Imóvel (R.M Imóveis) ---")
    print("[1] Apartamento (Base: R$ 700,00)")
    print("[2] Casa        (Base: R$ 900,00)")
    print("[3] Estúdio     (Base: R$ 1.200,00)")

    tipo = ler_opcao("Escolha o tipo de imóvel (1, 2 ou 3): ", ("1", "2", "3"))

    if tipo == "1":
        quartos = ler_inteiro_intervalo("Quantidade de quartos (1 ou 2): ", 1, 2)
        garagem = ler_opcao("Deseja vaga de garagem (+R$ 300,00)? (s/n): ", ("s", "n")) == "s"
        sem_criancas = ler_opcao("O cliente NÃO possui crianças (desconto de 5% no aluguel)? (s/n): ", ("s", "n")) == "s"
        return Apartamento(quartos=quartos, possui_garagem=garagem, sem_criancas=sem_criancas)

    if tipo == "2":
        quartos = ler_inteiro_intervalo("Quantidade de quartos (1 ou 2): ", 1, 2)
        garagem = ler_opcao("Deseja vaga de garagem (+R$ 300,00)? (s/n): ", ("s", "n")) == "s"
        return Casa(quartos=quartos, possui_garagem=garagem, sem_criancas=False)

    # Estúdio
    vagas_adicionais = ler_inteiro_intervalo(
        "O estúdio já inclui 2 vagas (R$ 250,00). Quantas vagas ADICIONAIS (R$ 60,00 cada) deseja? (0 ou mais): ",
        0,
        None,
    )
    return Estudio(vagas_adicionais=vagas_adicionais, sem_criancas=False)


def executar_sistema() -> None:
    print("=" * 64)
    print("BEM-VINDO AO RENTSMART — SISTEMA DE ORÇAMENTO DE LOCAÇÃO")
    print("=" * 64)

    while True:
        try:
            imovel = construir_imovel()
            parcelas_taxa = ler_inteiro_intervalo(
                f"Em quantas parcelas deseja pagar a taxa contratual de R$ 2.000,00 (1 a {Imovel.MAX_PARCELAS_TAXA})? ",
                1,
                Imovel.MAX_PARCELAS_TAXA,
            )

            orcamento = OrcamentoLocacao(imovel=imovel, parcelas_taxa=parcelas_taxa)
            print(orcamento.formatar_resumo())

            caminho_csv = orcamento.exportar_projecao_csv()
            print(f"Arquivo CSV com a projeção de 12 meses gerado em:\n  {caminho_csv}")

        except ValueError as erro:
            print(f"Erro de validação: {erro}")

        repetir = ler_opcao("\nDeseja gerar um novo orçamento? (s/n): ", ("s", "n"))
        if repetir == "n":
            print("\nEncerrando o RentSmart. Até logo!")
            break


if __name__ == "__main__":
    executar_sistema()
