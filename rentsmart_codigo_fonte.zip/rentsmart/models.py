from abc import ABC, abstractmethod


class Imovel(ABC):
    """Classe base abstrata para os imóveis da R.M Imóveis."""

    TAXA_CONTRATUAL_TOTAL = 2000.00
    MAX_PARCELAS_TAXA = 5

    def __init__(self, quartos: int = 1, sem_criancas: bool = False):
        self._validar_quartos(quartos)
        self.quartos = quartos
        self.sem_criancas = sem_criancas

    @staticmethod
    def _validar_quartos(quartos: int) -> None:
        if quartos not in (1, 2):
            raise ValueError("A quantidade de quartos deve ser 1 ou 2.")

    @property
    @abstractmethod
    def categoria(self) -> str:
        """Retorna o nome legível da categoria do imóvel."""

    @property
    @abstractmethod
    def aluguel_base(self) -> float:
        """Retorna o valor base mensal da categoria."""

    @abstractmethod
    def calcular_adicional_quartos(self) -> float:
        """Calcula o adicional mensal referente à quantidade de quartos."""

    @abstractmethod
    def calcular_adicional_garagem(self) -> float:
        """Calcula o adicional mensal referente às vagas de garagem/estacionamento."""

    def calcular_subtotal_antes_desconto(self) -> float:
        """Soma aluguel base + adicionais antes da aplicação de descontos."""
        return (
            self.aluguel_base
            + self.calcular_adicional_quartos()
            + self.calcular_adicional_garagem()
        )

    def calcular_desconto(self) -> float:
        """Retorna o valor de desconto aplicável ao imóvel."""
        return 0.0

    def calcular_aluguel_mensal(self) -> float:
        """Calcula o valor final do aluguel mensal após adicionais e descontos."""
        subtotal = self.calcular_subtotal_antes_desconto()
        desconto = self.calcular_desconto()
        return round(max(0.0, subtotal - desconto), 2)

    @abstractmethod
    def resumo_vagas(self) -> str:
        """Descrição legível das vagas contratadas."""


class Apartamento(Imovel):
    """Representa um apartamento disponível para locação."""

    ALUGUEL_BASE_1Q = 700.00
    ADICIONAL_2Q = 200.00
    VALOR_GARAGEM = 300.00
    PERCENTUAL_DESCONTO_SEM_CRIANCAS = 0.05

    def __init__(self, quartos: int = 1, possui_garagem: bool = False, sem_criancas: bool = False):
        super().__init__(quartos=quartos, sem_criancas=sem_criancas)
        self.possui_garagem = bool(possui_garagem)

    @property
    def categoria(self) -> str:
        return "Apartamento"

    @property
    def aluguel_base(self) -> float:
        return self.ALUGUEL_BASE_1Q

    def calcular_adicional_quartos(self) -> float:
        return self.ADICIONAL_2Q if self.quartos == 2 else 0.0

    def calcular_adicional_garagem(self) -> float:
        return self.VALOR_GARAGEM if self.possui_garagem else 0.0

    def calcular_desconto(self) -> float:
        """Aplica 5% de desconto sobre o aluguel com adicionais quando não há crianças."""
        if self.sem_criancas:
            subtotal = self.calcular_subtotal_antes_desconto()
            return round(subtotal * self.PERCENTUAL_DESCONTO_SEM_CRIANCAS, 2)
        return 0.0

    def resumo_vagas(self) -> str:
        return "1 vaga de garagem" if self.possui_garagem else "Sem vaga de garagem"


class Casa(Imovel):
    """Representa uma casa disponível para locação."""

    ALUGUEL_BASE_1Q = 900.00
    ADICIONAL_2Q = 250.00
    VALOR_GARAGEM = 300.00

    def __init__(self, quartos: int = 1, possui_garagem: bool = False, sem_criancas: bool = False):
        super().__init__(quartos=quartos, sem_criancas=sem_criancas)
        self.possui_garagem = bool(possui_garagem)

    @property
    def categoria(self) -> str:
        return "Casa"

    @property
    def aluguel_base(self) -> float:
        return self.ALUGUEL_BASE_1Q

    def calcular_adicional_quartos(self) -> float:
        return self.ADICIONAL_2Q if self.quartos == 2 else 0.0

    def calcular_adicional_garagem(self) -> float:
        return self.VALOR_GARAGEM if self.possui_garagem else 0.0

    def resumo_vagas(self) -> str:
        return "1 vaga de garagem" if self.possui_garagem else "Sem vaga de garagem"


class Estudio(Imovel):
    """Representa um estúdio disponível para locação."""

    ALUGUEL_BASE_ESTUDIO = 1200.00
    PACOTE_2_VAGAS = 250.00
    VALOR_VAGA_ADICIONAL = 60.00

    def __init__(self, vagas_adicionais: int = 0, sem_criancas: bool = False):
        # Estúdios possuem configuração padrão de 1 ambiente/quarto no modelo base
        super().__init__(quartos=1, sem_criancas=sem_criancas)
        if not isinstance(vagas_adicionais, int) or isinstance(vagas_adicionais, bool) or vagas_adicionais < 0:
            raise ValueError("A quantidade de vagas adicionais deve ser um número inteiro maior ou igual a zero.")
        self.vagas_adicionais = vagas_adicionais

    @property
    def categoria(self) -> str:
        return "Estúdio"

    @property
    def aluguel_base(self) -> float:
        return self.ALUGUEL_BASE_ESTUDIO

    def calcular_adicional_quartos(self) -> float:
        return 0.0

    def calcular_adicional_garagem(self) -> float:
        """Pacote inicial de 2 vagas por R$ 250,00 + R$ 60,00 por vaga adicional."""
        return round(self.PACOTE_2_VAGAS + (self.vagas_adicionais * self.VALOR_VAGA_ADICIONAL), 2)

    def resumo_vagas(self) -> str:
        total_vagas = 2 + self.vagas_adicionais
        if self.vagas_adicionais > 0:
            return f"{total_vagas} vagas (pacote de 2 + {self.vagas_adicionais} adicional(is))"
        return "2 vagas (pacote inicial)"
