import csv
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import List

from models import Imovel


@dataclass
class ParcelaMensal:
    mes: int
    rotulo_mes: str
    aluguel_mensal: float
    parcela_taxa_contratual: float
    total_mes: float


class OrcamentoLocacao:
    """Responsável pelo cálculo do orçamento, exibição detalhada e projeção de 12 meses."""

    def __init__(self, imovel: Imovel, parcelas_taxa: int = 1):
        self.imovel = imovel
        self.parcelas_taxa = self._validar_parcelas(parcelas_taxa)

    @staticmethod
    def _validar_parcelas(parcelas: int) -> int:
        if not isinstance(parcelas, int) or isinstance(parcelas, bool) or not (1 <= parcelas <= Imovel.MAX_PARCELAS_TAXA):
            raise ValueError(
                f"A taxa contratual pode ser parcelada de 1 a {Imovel.MAX_PARCELAS_TAXA} vezes."
            )
        return parcelas

    @property
    def valor_parcela_taxa(self) -> float:
        return round(self.imovel.TAXA_CONTRATUAL_TOTAL / self.parcelas_taxa, 2)

    def gerar_projecao_12_meses(self) -> List[ParcelaMensal]:
        """Gera a projeção detalhada mês a mês para os primeiros 12 meses de locação."""
        aluguel = self.imovel.calcular_aluguel_mensal()
        taxa_total = self.imovel.TAXA_CONTRATUAL_TOTAL
        parcela_padrao = round(taxa_total / self.parcelas_taxa, 2)
        acumulado_taxa = 0.0

        projecao: List[ParcelaMensal] = []
        for mes in range(1, 13):
            if mes <= self.parcelas_taxa:
                if mes < self.parcelas_taxa:
                    parcela_taxa = parcela_padrao
                    acumulado_taxa = round(acumulado_taxa + parcela_taxa, 2)
                else:
                    # Ajusta possíveis diferenças de centavos na última parcela
                    parcela_taxa = round(taxa_total - acumulado_taxa, 2)
            else:
                parcela_taxa = 0.0

            total_mes = round(aluguel + parcela_taxa, 2)
            projecao.append(
                ParcelaMensal(
                    mes=mes,
                    rotulo_mes=f"Mês {mes:02d}",
                    aluguel_mensal=aluguel,
                    parcela_taxa_contratual=parcela_taxa,
                    total_mes=total_mes,
                )
            )
        return projecao

    @staticmethod
    def _fmt_moeda(valor: float) -> str:
        """Formata valores numéricos no padrão monetário brasileiro (R$ 1.200,00)."""
        texto = f"{valor:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
        return f"R$ {texto}"

    def formatar_resumo(self) -> str:
        """Retorna o resumo completo do orçamento separando aluguel e taxa contratual."""
        aluguel_base = self.imovel.aluguel_base
        adic_quartos = self.imovel.calcular_adicional_quartos()
        adic_garagem = self.imovel.calcular_adicional_garagem()
        subtotal = self.imovel.calcular_subtotal_antes_desconto()
        desconto = self.imovel.calcular_desconto()
        aluguel_mensal = self.imovel.calcular_aluguel_mensal()
        projecao = self.gerar_projecao_12_meses()
        total_12_meses_com_taxa = round(sum(p.total_mes for p in projecao), 2)
        total_12_meses_aluguel = round(aluguel_mensal * 12, 2)

        linhas = [
            "",
            "=" * 64,
            "RENTSMART — RESUMO DETALHADO DO ORÇAMENTO DE LOCAÇÃO (R.M IMÓVEIS)",
            "=" * 64,
            f"Categoria do Imóvel : {self.imovel.categoria}",
            f"Quantidade de Quartos: {self.imovel.quartos}",
            f"Garagem/Estacionamento: {self.imovel.resumo_vagas()}",
            f"Sem Crianças (Ap.)  : {'Sim' if self.imovel.sem_criancas else 'Não'}",
            "-" * 64,
            "COMPOSIÇÃO DO ALUGUEL MENSAL:",
            f"  Aluguel Base                       : {self._fmt_moeda(aluguel_base)}",
            f"  Adicional de Quartos               : {self._fmt_moeda(adic_quartos)}",
            f"  Adicional de Garagem/Vagas         : {self._fmt_moeda(adic_garagem)}",
            f"  Subtotal antes do Desconto         : {self._fmt_moeda(subtotal)}",
            f"  Desconto Aplicado (5% Ap. s/ criança): -{self._fmt_moeda(desconto)}",
            f"  ALUGUEL MENSAL FINAL               : {self._fmt_moeda(aluguel_mensal)}",
            "-" * 64,
            "TAXA CONTRATUAL (COBRADA SEPARADAMENTE DO ALUGUEL MENSAL):",
            f"  Valor Total da Taxa Contratual     : {self._fmt_moeda(self.imovel.TAXA_CONTRATUAL_TOTAL)}",
            f"  Condição de Parcelamento           : {self.parcelas_taxa}x de {self._fmt_moeda(self.valor_parcela_taxa)}",
            "-" * 64,
            "VISÃO CONSOLIDADA DO 1º ANO (12 MESES):",
            f"  Total de Aluguéis (12 meses)       : {self._fmt_moeda(total_12_meses_aluguel)}",
            f"  Total Geral (12 Aluguéis + Taxa)   : {self._fmt_moeda(total_12_meses_com_taxa)}",
            "=" * 64,
        ]
        return "\n".join(linhas)

    def exportar_projecao_csv(self, caminho_arquivo: str | Path | None = None) -> Path:
        """Gera um arquivo CSV com a projeção detalhada dos 12 meses."""
        if caminho_arquivo is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            caminho = Path(f"projecao_12_meses_{timestamp}.csv")
        else:
            caminho = Path(caminho_arquivo)

        projecao = self.gerar_projecao_12_meses()

        with caminho.open(mode="w", newline="", encoding="utf-8-sig") as arquivo_csv:
            escritor = csv.writer(arquivo_csv, delimiter=";")
            escritor.writerow([
                "Mes",
                "Periodo",
                "Categoria_Imovel",
                "Quartos",
                "Vagas_Garagem",
                "Aluguel_Mensal_RS",
                "Parcela_Taxa_Contratual_RS",
                "Valor_Total_Mes_RS",
            ])
            for item in projecao:
                escritor.writerow([
                    item.mes,
                    item.rotulo_mes,
                    self.imovel.categoria,
                    self.imovel.quartos,
                    self.imovel.resumo_vagas(),
                    f"{item.aluguel_mensal:.2f}".replace(".", ","),
                    f"{item.parcela_taxa_contratual:.2f}".replace(".", ","),
                    f"{item.total_mes:.2f}".replace(".", ","),
                ])

        return caminho.resolve()
